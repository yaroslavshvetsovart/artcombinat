import { Navigation } from '@/components/Navigation';
import { Hero } from '@/sections/Hero';
import { Section } from '@/sections/Section';
import { Gallery } from '@/sections/Gallery';
import { Team } from '@/sections/Team';
import { Contacts } from '@/sections/Contacts';
import { Footer } from '@/sections/Footer';
import { sections } from '@/data/content';
import './App.css';

function App() {
  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      <main>
        <Hero />
        {sections.map((section, index) => (
          <Section
            key={section.id}
            id={section.id}
            title={section.title}
            subtitle={section.subtitle}
            description={section.description}
            images={section.images}
            index={index}
          />
        ))}
        <Gallery />
        <Team />
        <Contacts />
      </main>
      <Footer />
    </div>
  );
}

export default App;
