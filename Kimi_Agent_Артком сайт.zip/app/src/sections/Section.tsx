import { useEffect, useRef, useState } from 'react';
import { ArrowRight } from 'lucide-react';

interface SectionProps {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  images: string[];
  index: number;
}

export function Section({ id, title, subtitle, description, images, index }: SectionProps) {
  const sectionRef = useRef<HTMLElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const isEven = index % 2 === 0;

  return (
    <section
      id={id}
      ref={sectionRef}
      className={`py-20 lg:py-32 ${isEven ? 'bg-white' : 'bg-gray-50'}`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className={`grid lg:grid-cols-2 gap-12 lg:gap-20 items-center ${!isEven ? 'lg:flex-row-reverse' : ''}`}>
          {/* Content */}
          <div className={`${!isEven ? 'lg:order-2' : ''} ${isVisible ? 'animate-fade-in-left' : 'opacity-0'}`}>
            <span className="inline-block px-4 py-1.5 bg-amber-100 text-amber-700 text-sm font-medium rounded-full mb-4">
              {subtitle}
            </span>
            <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
              {title}
            </h2>
            <p className="text-lg text-gray-600 leading-relaxed mb-8">
              {description}
            </p>
            <button className="inline-flex items-center gap-2 text-amber-600 font-semibold hover:text-amber-700 transition-colors group">
              Подробнее
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>

          {/* Images Grid */}
          <div className={`${!isEven ? 'lg:order-1' : ''} ${isVisible ? 'animate-fade-in-right' : 'opacity-0'}`}>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4">
                <div className="aspect-[4/5] rounded-2xl overflow-hidden bg-gray-200 shadow-lg">
                  <img
                    src={images[0]}
                    alt={`${title} - 1`}
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = `https://placehold.co/600x750/92400e/ffffff?text=${encodeURIComponent(title)}`;
                    }}
                  />
                </div>
              </div>
              <div className="space-y-4 pt-8">
                <div className="aspect-square rounded-2xl overflow-hidden bg-gray-200 shadow-lg">
                  <img
                    src={images[1]}
                    alt={`${title} - 2`}
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = `https://placehold.co/600x600/d97706/ffffff?text=${encodeURIComponent(title)}`;
                    }}
                  />
                </div>
                <div className="aspect-[4/3] rounded-2xl overflow-hidden bg-gray-200 shadow-lg">
                  <img
                    src={images[2]}
                    alt={`${title} - 3`}
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = `https://placehold.co/600x450/f59e0b/ffffff?text=${encodeURIComponent(title)}`;
                    }}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
