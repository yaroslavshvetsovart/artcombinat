import { Palette, Instagram, Facebook, Youtube, Mail } from 'lucide-react';
import { siteData, sections } from '@/data/content';

export function Footer() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const socialLinks = [
    { icon: Instagram, href: '#', label: 'Instagram' },
    { icon: Facebook, href: '#', label: 'Facebook' },
    { icon: Youtube, href: '#', label: 'YouTube' },
    { icon: Mail, href: `mailto:${siteData.email}`, label: 'Email' },
  ];

  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main Footer */}
        <div className="py-16 grid md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand */}
          <div className="lg:col-span-2">
            <div className="flex items-center gap-2 mb-6">
              <Palette className="w-8 h-8 text-amber-500" />
              <span className="text-2xl font-bold">{siteData.name}</span>
            </div>
            <p className="text-gray-400 mb-6 max-w-md">
              {siteData.description}
            </p>
            <div className="flex gap-4">
              {socialLinks.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-amber-500 transition-colors"
                  aria-label={link.label}
                >
                  <link.icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-6">Разделы</h4>
            <ul className="space-y-3">
              {sections.map((section) => (
                <li key={section.id}>
                  <button
                    onClick={() => scrollToSection(section.id)}
                    className="text-gray-400 hover:text-amber-400 transition-colors"
                  >
                    {section.title}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-semibold mb-6">Контакты</h4>
            <ul className="space-y-3 text-gray-400">
              <li>{siteData.address}</li>
              <li>
                <a href={`tel:${siteData.phone.replace(/\s/g, '')}`} className="hover:text-amber-400 transition-colors">
                  {siteData.phone}
                </a>
              </li>
              <li>
                <a href={`mailto:${siteData.email}`} className="hover:text-amber-400 transition-colors">
                  {siteData.email}
                </a>
              </li>
              <li className="pt-2">{siteData.workingHours}</li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="py-6 border-t border-white/10 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="text-gray-500 text-sm">
            © {new Date().getFullYear()} {siteData.name}. Все права защищены.
          </p>
          <div className="flex gap-6 text-sm text-gray-500">
            <a href="#" className="hover:text-amber-400 transition-colors">
              Политика конфиденциальности
            </a>
            <a href="#" className="hover:text-amber-400 transition-colors">
              Условия использования
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
