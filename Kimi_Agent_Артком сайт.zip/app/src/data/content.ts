// Данные для сайта АРТкомбинат

export const siteData = {
  name: "АРТкомбинат",
  tagline: "Творческое объединение художников",
  description: "Профессиональное художественное предприятие, создающее уникальные произведения искусства для интерьеров, музеев и частных коллекций",
  address: "г. Москва, ул. Художников, 15",
  phone: "+7 (495) 123-45-67",
  email: "info@artcombinat.ru",
  workingHours: "Пн-Пт: 9:00 - 18:00",
};

export const sections = [
  {
    id: "interior",
    title: "Интерьер",
    subtitle: "Художественное оформление пространств",
    description: "Создаем уникальные интерьерные решения, превращаем пространства в произведения искусства. Роспись стен, панно, декоративные элементы.",
    images: [
      "/images/interior-1.jpg",
      "/images/interior-2.jpg",
      "/images/interior-3.jpg",
    ],
  },
  {
    id: "museums",
    title: "Музеи",
    subtitle: "Экспозиции и выставочные проекты",
    description: "Разработка и создание музейных экспозиций, выставочных стендов, информационных панно и диорам.",
    images: [
      "/images/museum-1.jpg",
      "/images/museum-2.jpg",
      "/images/museum-3.jpg",
    ],
  },
  {
    id: "pleinair",
    title: "Пленеры",
    subtitle: "Выездная творческая работа",
    description: "Организация и проведение пленэров, выездных творческих сессий для художников и любителей живописи.",
    images: [
      "/images/pleinair-1.jpg",
      "/images/pleinair-2.jpg",
      "/images/pleinair-3.jpg",
    ],
  },
  {
    id: "works",
    title: "Работы",
    subtitle: "Живопись и графика",
    description: "Картины, графические работы, иллюстрации. Уникальные произведения от мастеров АРТкомбината.",
    images: [
      "/images/work-1.jpg",
      "/images/work-2.jpg",
      "/images/work-3.jpg",
    ],
  },
  {
    id: "sgraffito",
    title: "Сграффито",
    subtitle: "Древняя техника декоративной штукатурки",
    description: "Традиционная техника нанесения декоративной штукатурки с последующим процарапыванием рисунка. Уникальные фактуры и узоры.",
    images: [
      "/images/sgraffito-1.jpg",
      "/images/sgraffito-2.jpg",
      "/images/sgraffito-3.jpg",
    ],
  },
  {
    id: "sculpture",
    title: "Скульптуры",
    subtitle: "Объемное искусство",
    description: "Скульптурные работы различных масштабов: от миниатюр до монументальных композиций. Гипс, бронза, камень, металл.",
    images: [
      "/images/sculpture-1.jpg",
      "/images/sculpture-2.jpg",
      "/images/sculpture-3.jpg",
    ],
  },
];

export const galleryImages = [
  { id: 1, src: "/images/gallery-1.jpg", title: "Весенний пейзаж", category: "Живопись" },
  { id: 2, src: "/images/gallery-2.jpg", title: "Интерьерная композиция", category: "Интерьер" },
  { id: 3, src: "/images/gallery-3.jpg", title: "Скульптура 'Гармония'", category: "Скульптура" },
  { id: 4, src: "/images/gallery-4.jpg", title: "Сграффито панно", category: "Сграффито" },
  { id: 5, src: "/images/gallery-5.jpg", title: "Музейная экспозиция", category: "Музеи" },
  { id: 6, src: "/images/gallery-6.jpg", title: "Пленэр в Крыму", category: "Пленеры" },
];

export const teamMembers = [
  {
    name: "Александр Петров",
    role: "Руководитель студии",
    description: "Член Союза художников, более 25 лет опыта",
  },
  {
    name: "Елена Смирнова",
    role: "Главный художник",
    description: "Специалист по интерьерной живописи",
  },
  {
    name: "Михаил Иванов",
    role: "Скульптор",
    description: "Монументальная и станковая скульптура",
  },
];
