import { useState, useEffect } from 'react';
import { Menu, X, Palette } from 'lucide-react';
import { siteData, sections } from '@/data/content';

export function Navigation() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsMobileMenuOpen(false);
    }
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-white/95 backdrop-blur-md shadow-lg py-3'
          : 'bg-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <button
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="flex items-center gap-2 group"
          >
            <Palette className={`w-8 h-8 transition-colors ${
              isScrolled ? 'text-amber-600' : 'text-white'
            } group-hover:text-amber-500`} />
            <span className={`text-xl font-bold transition-colors ${
              isScrolled ? 'text-gray-900' : 'text-white'
            }`}>
              {siteData.name}
            </span>
          </button>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center gap-1">
            {sections.map((section) => (
              <button
                key={section.id}
                onClick={() => scrollToSection(section.id)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all hover:bg-amber-500/10 ${
                  isScrolled ? 'text-gray-700 hover:text-amber-600' : 'text-white/90 hover:text-white'
                }`}
              >
                {section.title}
              </button>
            ))}
            <button
              onClick={() => scrollToSection('gallery')}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all hover:bg-amber-500/10 ${
                isScrolled ? 'text-gray-700 hover:text-amber-600' : 'text-white/90 hover:text-white'
              }`}
            >
              Галерея
            </button>
            <button
              onClick={() => scrollToSection('contacts')}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all hover:bg-amber-500/10 ${
                isScrolled ? 'text-gray-700 hover:text-amber-600' : 'text-white/90 hover:text-white'
              }`}
            >
              Контакты
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className={`lg:hidden p-2 rounded-lg transition-colors ${
              isScrolled ? 'text-gray-700 hover:bg-gray-100' : 'text-white hover:bg-white/10'
            }`}
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="lg:hidden mt-4 pb-4 border-t border-gray-200/20 pt-4">
            <div className="flex flex-col gap-2">
              {sections.map((section) => (
                <button
                  key={section.id}
                  onClick={() => scrollToSection(section.id)}
                  className={`px-4 py-3 rounded-lg text-left font-medium transition-colors ${
                    isScrolled
                      ? 'text-gray-700 hover:bg-amber-50 hover:text-amber-600'
                      : 'text-white hover:bg-white/10'
                  }`}
                >
                  {section.title}
                </button>
              ))}
              <button
                onClick={() => scrollToSection('gallery')}
                className={`px-4 py-3 rounded-lg text-left font-medium transition-colors ${
                  isScrolled
                    ? 'text-gray-700 hover:bg-amber-50 hover:text-amber-600'
                    : 'text-white hover:bg-white/10'
                }`}
              >
                Галерея
              </button>
              <button
                onClick={() => scrollToSection('contacts')}
                className={`px-4 py-3 rounded-lg text-left font-medium transition-colors ${
                  isScrolled
                    ? 'text-gray-700 hover:bg-amber-50 hover:text-amber-600'
                    : 'text-white hover:bg-white/10'
                }`}
              >
                Контакты
              </button>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
